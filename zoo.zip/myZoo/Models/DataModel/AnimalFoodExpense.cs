﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myZoo.Models.DataModel
{
    public class AnimalFoodExpense
    {
        public string AnimalName { get; set; }

        public double TotalExpense { get; set; }
    }

    public class TotalFoodExpense
    {
        public List<AnimalFoodExpense> ListAnimalExpense { get; set; }

        public double TotPrice { get; set; }
    }
}
