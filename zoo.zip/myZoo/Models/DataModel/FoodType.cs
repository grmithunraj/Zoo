﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myZoo.Models.DataModel
{
    public class FoodType
    {
        public double Meat { get; set; }

        public double Fruit { get; set; }
    }
}
