﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myZoo.Models.DataModel
{
    public class AnimalType
    {
        public string AnimalName { get; set; }

        public double Rate { get; set; }

        public string EatType { get; set; }

        public string percentage { get; set; }

        public bool Isomnivores { get; set; } = false;
    }
}
