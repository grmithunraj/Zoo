﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using myZoo.Business.Interface;
using myZoo.Models;
using myZoo.Models.DataModel;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace myZoo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IReadFileService _readFileService;
        private IZooDailyService _zooDailyService;

        public HomeController(ILogger<HomeController> logger,IReadFileService readFileService,IZooDailyService zooDailyService)
        {
            _logger = logger;
            _readFileService = readFileService;
            _zooDailyService = zooDailyService;

        }

        public IActionResult Index()
        {
           var result = _zooDailyService.GetDailyExpenseforFeeding();
            ViewBag.Details = result;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public TotalFoodExpense getdetails()
        {
            return _zooDailyService.GetDailyExpenseforFeeding();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
