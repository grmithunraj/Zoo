﻿using myZoo.Business.Interface;
using myZoo.Models.DataModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace myZoo.Business
{
    public class ReadFileService: IReadFileService
    {
        public T GetXmlFileValues<T>(string fileName)
        {
            StreamReader str = new System.IO.StreamReader(Directory.GetCurrentDirectory() + @"\Models\" + fileName);
            XmlSerializer xSerializer = new XmlSerializer(typeof(T));
            var objZoo = (T)xSerializer.Deserialize(str);
            str.Close();
            return objZoo;
        }

        public List<AnimalType> GetAnimalTypeDetails(string fileName)
        {
            string textFile = Directory.GetCurrentDirectory() + @"\Models\" + fileName;
            string[] lines = File.ReadAllLines(textFile);
            List<AnimalType> lstAnimal = new List<AnimalType>();
            foreach (string line in lines)
            {
                AnimalType objAnimal = new AnimalType();
                var details = line.Split(";");
                if (details[0] != null)
                {
                    objAnimal.AnimalName = details[0].ToString().Trim();

                }
                if (details[1] != null)
                {
                    objAnimal.Rate = Convert.ToDouble(details[1].ToString().Trim());
                }

                if (details[2] != null)
                {
                    objAnimal.EatType = details[2].ToString().Trim();
                }
                if (details[3] != null)
                {
                    objAnimal.percentage = details[3].ToString().Trim();
                    if(details[3].ToString().Trim().Length>0)
                    {
                        objAnimal.Isomnivores = true;
                    }
                }
                lstAnimal.Add(objAnimal);
            }
            return lstAnimal;

        }
        public FoodType GetFoodRate(string fileName)
        {
            string textFile = Directory.GetCurrentDirectory() + @"\Models\" + fileName;
            string[] lines = File.ReadAllLines(textFile);
            FoodType objFoodType = new FoodType();
            foreach (string line in lines)
            {
                var type = line.Split("=");
                if (type[0] != null)
                {
                    if (type[0].ToString().Trim() == "Meat")
                    {
                        if(type[1] !=null)
                        {
                            objFoodType.Meat = Convert.ToDouble(type[1].ToString().Trim());
                        }
                    }
                    if (type[0].ToString().Trim() == "Fruit")
                    {
                        if (type[1] != null)
                        {
                            objFoodType.Fruit = Convert.ToDouble(type[1].ToString().Trim());
                        }
                    }
                }
            }
            return objFoodType;

        }
    }
}
