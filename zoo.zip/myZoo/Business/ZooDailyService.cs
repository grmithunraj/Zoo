﻿using myZoo.Business.Interface;
using myZoo.Models.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myZoo.Business
{
    public class ZooDailyService: IZooDailyService
    {
        private IReadFileService _readFileService;
        public static string ZoofileName = "Zoo.xml";
        public static string animalfileName = "animal.csv";
        public static string pricesfileName = "Prices.txt";
        public ZooDailyService(IReadFileService readFileService)
        {
            _readFileService = readFileService;
        }

        public TotalFoodExpense GetDailyExpenseforFeeding()
        {
         var animalexpense= calculateDailyExpense(GetAnimalDetails(), GetAnimalTypes(), GetFoodType());
            double cummulativeexpense = 0;
            foreach(var item in animalexpense)
            {
                cummulativeexpense = cummulativeexpense + item.TotalExpense;
            }

            TotalFoodExpense totalFoodExpense = new TotalFoodExpense();
            totalFoodExpense.ListAnimalExpense = new List<AnimalFoodExpense>();
            totalFoodExpense.ListAnimalExpense.AddRange(animalexpense);
            totalFoodExpense.TotPrice = cummulativeexpense;
            return totalFoodExpense;
        }

        private Zoo GetAnimalDetails()
        {

            var zooAnimals = _readFileService.GetXmlFileValues<Zoo>(ZoofileName);

            return zooAnimals;
        }

        private List<AnimalType> GetAnimalTypes()
        {
            return _readFileService.GetAnimalTypeDetails(animalfileName);
        }

        private FoodType GetFoodType()
        {
            return _readFileService.GetFoodRate(pricesfileName);
        }

        private List<AnimalFoodExpense> calculateDailyExpense(Zoo objzoo, List<AnimalType> lstType, FoodType foodType)
        {
            Double TotalExpense = 0;
            List<AnimalFoodExpense> lstanimalFoodExpenses = new List<AnimalFoodExpense>();
            AnimalFoodExpense animalFoodExpense = null;
            if (objzoo.Giraffes.Giraffe.Count > 0)
            {
                animalFoodExpense = new AnimalFoodExpense();
                var objGirafe = lstType.Find(x => x.AnimalName == "Giraffe");
                foreach (var girafe in objzoo.Giraffes.Giraffe)
                {
                    TotalExpense = TotalExpense + GetCalculatedValue(girafe.Kg, objGirafe, foodType);
                }
                animalFoodExpense.AnimalName = objGirafe.AnimalName;
                animalFoodExpense.TotalExpense = TotalExpense;
                lstanimalFoodExpenses.Add(animalFoodExpense);
            }
            if (objzoo.Lions.Lion.Count > 0)
            {
                TotalExpense = 0;
                animalFoodExpense = new AnimalFoodExpense();
                var obLion = lstType.Find(x => x.AnimalName == "Lion");
                foreach (var Lion in objzoo.Lions.Lion)
                {
                    TotalExpense = TotalExpense + GetCalculatedValue(Lion.Kg, obLion, foodType);
                }
                animalFoodExpense.AnimalName = obLion.AnimalName;
                animalFoodExpense.TotalExpense = TotalExpense;
                lstanimalFoodExpenses.Add(animalFoodExpense);
            }
            if (objzoo.Piranhas.Piranha.Count > 0)
            {
                TotalExpense = 0;
                animalFoodExpense = new AnimalFoodExpense();
                var obPiranha = lstType.Find(x => x.AnimalName == "Piranha");
                foreach (var Piranha in objzoo.Piranhas.Piranha)
                {
                    TotalExpense = TotalExpense + GetCalculatedValue(Piranha.Kg, obPiranha, foodType);
                }
                animalFoodExpense.AnimalName = obPiranha.AnimalName;
                animalFoodExpense.TotalExpense = TotalExpense;
                lstanimalFoodExpenses.Add(animalFoodExpense);
            }

            if (objzoo.Tigers.Tiger.Count > 0)
            {
                TotalExpense = 0;
                animalFoodExpense = new AnimalFoodExpense();
                var obTiger = lstType.Find(x => x.AnimalName == "Tiger");
                foreach (var Tiger in objzoo.Tigers.Tiger)
                {
                    TotalExpense = TotalExpense + GetCalculatedValue(Tiger.Kg, obTiger, foodType);
                }
                animalFoodExpense.AnimalName = obTiger.AnimalName;
                animalFoodExpense.TotalExpense = TotalExpense;
                lstanimalFoodExpenses.Add(animalFoodExpense);
            }

            if (objzoo.Wolves.Wolf.Count > 0)
            {
                TotalExpense = 0;
                animalFoodExpense = new AnimalFoodExpense();
                var obWolf = lstType.Find(x => x.AnimalName == "Wolf");
                foreach (var Wolf in objzoo.Wolves.Wolf)
                {
                    TotalExpense = TotalExpense + GetCalculatedValue(Wolf.Kg, obWolf, foodType);
                }
                animalFoodExpense.AnimalName = obWolf.AnimalName;
                animalFoodExpense.TotalExpense = TotalExpense;
                lstanimalFoodExpenses.Add(animalFoodExpense);
            }
            if (objzoo.Zebras.Zebra.Count > 0)
            {
                TotalExpense = 0;
                animalFoodExpense = new AnimalFoodExpense();
                var obZebra = lstType.Find(x => x.AnimalName == "Zebra");
                foreach (var Zebra in objzoo.Zebras.Zebra)
                {
                    TotalExpense = TotalExpense + GetCalculatedValue(Zebra.Kg, obZebra, foodType);
                }
                animalFoodExpense.AnimalName = obZebra.AnimalName;
                animalFoodExpense.TotalExpense = TotalExpense;
                lstanimalFoodExpenses.Add(animalFoodExpense);
            }

            return lstanimalFoodExpenses;

        }

        private double GetCalculatedValue(string weight, AnimalType animalType, FoodType foodType)
        {
            // AnimalFoodExpense animalFoodExpense = new AnimalFoodExpense();

            double TotExpense = 0;
            if (animalType.Isomnivores)
            {
                var percenagevalue = animalType.percentage.Split("%");
                var meattype = (animalType.Rate * Convert.ToDouble(percenagevalue[0].ToString().Trim())) / 100;
                double meatrate = Convert.ToDouble(weight) * meattype * foodType.Meat;
                double fruitrate = Convert.ToDouble(weight) * (animalType.Rate - meattype) * foodType.Fruit;
                // animalFoodExpense.AnimalName = animalType.AnimalName;
                TotExpense = meatrate + fruitrate;


            }
            else
            {
                if (animalType.EatType == "fruit")
                {
                    //animalFoodExpense.AnimalName = animalType.AnimalName;
                    TotExpense = Convert.ToDouble(weight) * animalType.Rate * foodType.Fruit;
                }
                else
                {
                    //animalFoodExpense.AnimalName = animalType.AnimalName;
                    TotExpense = Convert.ToDouble(weight) * animalType.Rate * foodType.Meat;
                }
            }

            return TotExpense;

        }



    }
}
