﻿using myZoo.Models.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myZoo.Business.Interface
{
   public interface IZooDailyService
    {
        TotalFoodExpense GetDailyExpenseforFeeding();
    }
}
