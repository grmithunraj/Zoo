﻿using myZoo.Models.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myZoo.Business.Interface
{
    public interface IReadFileService
    {
        T GetXmlFileValues<T>(string fileName);
        List<AnimalType> GetAnimalTypeDetails(string fileName);

        FoodType GetFoodRate(string fileName);
    }
}
